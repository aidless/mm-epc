arXiv Submission: Multi-Modal Emergent Policy Contagion (MM-EPC)

Files included:
- mm_epc_paper.tex: Main LaTeX source
- mm_epc_paper.bib: Bibliography (BibTeX format)
- references.bib: Additional references
- *.png/*.pdf: Figures (5 total)

Compilation instructions:
1. pdflatex mm_epc_paper.tex
2. bibtex mm_epc_paper
3. pdflatex mm_epc_paper.tex
4. pdflatex mm_epc_paper.tex

Required packages (standard LaTeX):
- graphicx, booktabs, amsmath, amssymb, hyperref

The paper has been successfully compiled with MiKTeX 25.12.

Contact: [TODO: Add contact email]
